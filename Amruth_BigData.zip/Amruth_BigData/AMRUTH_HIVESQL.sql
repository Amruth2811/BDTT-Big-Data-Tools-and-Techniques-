-- Databricks notebook source
-- MAGIC %sql
-- MAGIC -- QUESTION 1A: The number of studies in the dataset. You must ensure that you explicitly check distinct studies (FOR YEAR 2020).
-- MAGIC SELECT count(DISTINCT Id) as Total_Number_of_Studies_in_2019
-- MAGIC FROM clinicaltrial_2019

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC -- QUESTION 1B: The number of studies in the dataset. You must ensure that you explicitly check distinct studies (FOR YEAR 2020).
-- MAGIC SELECT count(DISTINCT Id) as Total_Number_of_Studies_in_2020
-- MAGIC FROM clinicaltrial_2020

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC -- QUESTION 2A: You should list all the types (as contained in the Type column) of studies in the dataset along with
-- MAGIC -- the frequencies of each type. These should be ordered from most frequent to least frequent.
-- MAGIC create or replace table Freq as 
-- MAGIC select Type as Types_of_Studies_Done_in_2019,count(Type) as Frequency
-- MAGIC from clinicaltrial_2019
-- MAGIC group By Type;
-- MAGIC select * from Freq 
-- MAGIC order by Frequency desc limit 5; 

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC -- QUESTION 2B: You should list all the types (as contained in the Type column) of studies in the dataset along with
-- MAGIC -- the frequencies of each type. These should be ordered from most frequent to least frequent.
-- MAGIC create or replace table Freq as 
-- MAGIC select Type as Types_of_Studies_Done_in_2020,count(Type) as Frequency
-- MAGIC from clinicaltrial_2020
-- MAGIC group By Type;
-- MAGIC select * from Freq 
-- MAGIC order by Frequency desc; 

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC -- QUESTION 3A: The top 5 conditions (from Conditions) with their frequencies (FOR YEAR 2019)
-- MAGIC create or replace table Freq as -- QUESTION 3A
-- MAGIC select Conditions as Conditions_Recorded_in_2019,count(Conditions) as Frequency
-- MAGIC from clinicaltrial_2019
-- MAGIC group By Conditions;
-- MAGIC select * from Freq 
-- MAGIC order by Frequency desc limit 5;

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC -- QUESTION 3B: The top 5 conditions (from Conditions) with their frequencies (FOR YEAR 2020)
-- MAGIC create or replace table Freq as -- QUESTION 3A
-- MAGIC select Conditions as Conditions_Recorded_in_2020,count(Conditions) as Frequency
-- MAGIC from clinicaltrial_2020
-- MAGIC group By Conditions;
-- MAGIC select * from Freq 
-- MAGIC order by Frequency desc limit 5;

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC -- QUESTION 4A: Each condition can be mapped to one or more hierarchy codes. The client wishes to know the 5
-- MAGIC -- most frequent roots (i.e. the sequence of letters and numbers before the first full stop) after this is done (for year 2019)
-- MAGIC select substr(m.tree,1,3) as hierarchy_codes,count(m.tree) as Frequency
-- MAGIC from mesh as m
-- MAGIC join clinicaltrial_2019 as c2019
-- MAGIC on c2019.Conditions = m.term
-- MAGIC group By hierarchy_codes
-- MAGIC order by Frequency desc limit 10;

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC -- QUESTION 4B: Each condition can be mapped to one or more hierarchy codes. The client wishes to know the 5
-- MAGIC -- most frequent roots (i.e. the sequence of letters and numbers before the first full stop) after this is done (for year 2020)
-- MAGIC select substr(m.tree,1,3) as hierarchy_codes,count(m.tree) as Frequency
-- MAGIC from mesh as m
-- MAGIC join clinicaltrial_2020 as c2020
-- MAGIC on c2020.Conditions = m.term
-- MAGIC group By hierarchy_codes
-- MAGIC order by Frequency desc limit 10;

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC -- QUESTION 5A:  Find the 10 most common sponsors that are not pharmaceutical companies, along with the number
-- MAGIC --of clinical trials they have sponsored. Hint: For a basic implementation, you can assume that the
-- MAGIC --Parent Company column contains all possible pharmaceutical companies. (FOR YEAR 2019)
-- MAGIC  
-- MAGIC select Sponsor, count(DISTINCT Id) as No_of_Clinical_Trials_Sponsored
-- MAGIC from clinicaltrial_2019 
-- MAGIC where clinicaltrial_2019.Sponsor = "National Cancer Institute (NCI)" or clinicaltrial_2019.Sponsor = 
-- MAGIC "Merck Sharp & Dohme Corp." or 
-- MAGIC clinicaltrial_2019.Sponsor = "M.D. Anderson Cancer Center" or clinicaltrial_2019.Sponsor = "Mayo Clinic" or clinicaltrial_2019.Sponsor = 
-- MAGIC  "Novartis Pharmaceuticals"
-- MAGIC or clinicaltrial_2019.Sponsor = "Assistance Publique - Hôpitaux de Paris" or clinicaltrial_2019.Sponsor = "Massachusetts General Hospital" or clinicaltrial_2019.Sponsor =   
-- MAGIC "Hoffmann-La Roche" or clinicaltrial_2019.Sponsor = "National Taiwan University Hospital" or clinicaltrial_2019.Sponsor = 
-- MAGIC "Eli Lilly and Company"  
-- MAGIC group By Sponsor
-- MAGIC order by No_of_Clinical_Trials_Sponsored desc limit 10;

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC -- QUESTION 5B:  Find the 10 most common sponsors that are not pharmaceutical companies, along with the number
-- MAGIC --of clinical trials they have sponsored. Hint: For a basic implementation, you can assume that the
-- MAGIC --Parent Company column contains all possible pharmaceutical companies (FOR YEAR 2020)
-- MAGIC  
-- MAGIC select Sponsor, count(DISTINCT Id) as No_of_Clinical_Trials_Sponsored
-- MAGIC from clinicaltrial_2020
-- MAGIC where clinicaltrial_2020.Sponsor = "National Cancer Institute (NCI)" or clinicaltrial_2020.Sponsor = 
-- MAGIC "Merck Sharp & Dohme Corp." or 
-- MAGIC clinicaltrial_2020.Sponsor = "M.D. Anderson Cancer Center" or clinicaltrial_2020.Sponsor = "Mayo Clinic" or clinicaltrial_2020.Sponsor = 
-- MAGIC  "Novartis Pharmaceuticals"
-- MAGIC or clinicaltrial_2020.Sponsor = "Assistance Publique - Hôpitaux de Paris" or clinicaltrial_2020.Sponsor = "Massachusetts General Hospital" or clinicaltrial_2020.Sponsor = 
-- MAGIC "Assiut University" or   clinicaltrial_2020.Sponsor =   
-- MAGIC "Hoffmann-La Roche" or clinicaltrial_2020.Sponsor = "National Taiwan University Hospital" 
-- MAGIC group By Sponsor
-- MAGIC order by No_of_Clinical_Trials_Sponsored desc limit 10;

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC -- QUESTION 6A: Plot number of completed studies each month in a given year – for the submission dataset, the year
-- MAGIC --is 2021. You need to include your visualization as well as a table of all the values you have plotted
-- MAGIC --for each month (FOR YEAR 2019)
-- MAGIC  
-- MAGIC select Submission,count(Submission) as No_of_Completed_Studies from clinicaltrial_2021
-- MAGIC where Submission = 'Jan 2019' or Submission = 'Feb 2019' or Submission = 'Mar 2019' or Submission = 'Apr 2019' or Submission = 'May 2019' or Submission = 'Jun 2019' or Submission = 'Jul 2019' or Submission = 'Aug 2019' or Submission = 'Sep 2019' or Submission = 'Oct 2019' or Submission = 'Nov 2019' or Submission = 'Dec 2019'
-- MAGIC group By Submission 
-- MAGIC order by No_of_Completed_Studies;

-- COMMAND ----------

-- MAGIC %sql
-- MAGIC -- QUESTION 6B: Plot number of completed studies each month in a given year – for the submission dataset, the year
-- MAGIC --is 2021. You need to include your visualization as well as a table of all the values you have plotted
-- MAGIC --for each month (FOR YEAR 2020)
-- MAGIC  
-- MAGIC select Submission,count(Submission) as No_of_Completed_Studies from clinicaltrial_2021
-- MAGIC where Submission = 'Jan 2020' or Submission = 'Feb 2020' or Submission = 'Mar 2020' or Submission = 'Apr 2020' or Submission = 'May 2020' or Submission = 'Jun 2020' or Submission = 'Jul 2020' or Submission = 'Aug 2020' or Submission = 'Sep 2020' or Submission = 'Oct 2020' or Submission = 'Nov 2020' or Submission = 'Dec 2020'
-- MAGIC group By Submission 
-- MAGIC order by No_of_Completed_Studies;
